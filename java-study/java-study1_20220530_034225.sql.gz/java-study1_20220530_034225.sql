-- MySQL dump 10.13  Distrib 5.7.30, for Linux (x86_64)
--
-- Host: localhost    Database: java-study1
-- ------------------------------------------------------
-- Server version	5.7.30-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `b_node`
--

DROP TABLE IF EXISTS `b_node`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_node` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `node_code` varchar(255) DEFAULT NULL,
  `node_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_rane32bjm54fe4579icc37paa` (`node_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_node`
--

LOCK TABLES `b_node` WRITE;
/*!40000 ALTER TABLE `b_node` DISABLE KEYS */;
/*!40000 ALTER TABLE `b_node` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_node_link`
--

DROP TABLE IF EXISTS `b_node_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_node_link` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `is_deleted` int(11) DEFAULT NULL,
  `flow_type` varchar(255) DEFAULT NULL,
  `type_code_list` varchar(255) NOT NULL,
  `end_node` varchar(255) DEFAULT NULL,
  `start_node` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKj8r55v462q3rqtsvdtcqidh2q` (`end_node`),
  KEY `FKq2fgokjdbnk1dioiwyj68d3hl` (`start_node`),
  CONSTRAINT `FKj8r55v462q3rqtsvdtcqidh2q` FOREIGN KEY (`end_node`) REFERENCES `b_node` (`node_code`),
  CONSTRAINT `FKq2fgokjdbnk1dioiwyj68d3hl` FOREIGN KEY (`start_node`) REFERENCES `b_node` (`node_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_node_link`
--

LOCK TABLES `b_node_link` WRITE;
/*!40000 ALTER TABLE `b_node_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `b_node_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_node_type`
--

DROP TABLE IF EXISTS `b_node_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_node_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type_code` varchar(255) DEFAULT NULL,
  `type_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_node_type`
--

LOCK TABLES `b_node_type` WRITE;
/*!40000 ALTER TABLE `b_node_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `b_node_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_outlay_price`
--

DROP TABLE IF EXISTS `b_outlay_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_outlay_price` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `contract` varchar(255) DEFAULT NULL,
  `is_deleted` int(11) DEFAULT NULL,
  `limit_price` decimal(19,2) DEFAULT NULL,
  `outlay_code` varchar(255) DEFAULT NULL,
  `outlay_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_outlay_price`
--

LOCK TABLES `b_outlay_price` WRITE;
/*!40000 ALTER TABLE `b_outlay_price` DISABLE KEYS */;
/*!40000 ALTER TABLE `b_outlay_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `p_proxy_category`
--

DROP TABLE IF EXISTS `p_proxy_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p_proxy_category` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `category_id` varchar(255) DEFAULT NULL,
  `store_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `p_proxy_category`
--

LOCK TABLES `p_proxy_category` WRITE;
/*!40000 ALTER TABLE `p_proxy_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_proxy_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `p_proxy_product`
--

DROP TABLE IF EXISTS `p_proxy_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p_proxy_product` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content_html` varchar(255) DEFAULT NULL,
  `product_desc` varchar(255) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `store_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `p_proxy_product`
--

LOCK TABLES `p_proxy_product` WRITE;
/*!40000 ALTER TABLE `p_proxy_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_proxy_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `p_proxy_product_category`
--

DROP TABLE IF EXISTS `p_proxy_product_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p_proxy_product_category` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `category_id` varchar(255) DEFAULT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `p_proxy_product_category`
--

LOCK TABLES `p_proxy_product_category` WRITE;
/*!40000 ALTER TABLE `p_proxy_product_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_proxy_product_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `p_proxy_product_node_link`
--

DROP TABLE IF EXISTS `p_proxy_product_node_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p_proxy_product_node_link` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `end_node_code` varchar(255) DEFAULT NULL,
  `flow_type` int(11) DEFAULT NULL,
  `product_id` varchar(255) DEFAULT NULL,
  `start_node_code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `p_proxy_product_node_link`
--

LOCK TABLES `p_proxy_product_node_link` WRITE;
/*!40000 ALTER TABLE `p_proxy_product_node_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_proxy_product_node_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `p_proxy_product_outlay_price`
--

DROP TABLE IF EXISTS `p_proxy_product_outlay_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p_proxy_product_outlay_price` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `amount` varchar(255) DEFAULT NULL,
  `outlay_code` varchar(255) DEFAULT NULL,
  `product_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `p_proxy_product_outlay_price`
--

LOCK TABLES `p_proxy_product_outlay_price` WRITE;
/*!40000 ALTER TABLE `p_proxy_product_outlay_price` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_proxy_product_outlay_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `p_proxy_store`
--

DROP TABLE IF EXISTS `p_proxy_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p_proxy_store` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `business_license` varchar(255) DEFAULT NULL,
  `is_deleted` int(11) DEFAULT NULL,
  `store_code` varchar(255) DEFAULT NULL,
  `store_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `p_proxy_store`
--

LOCK TABLES `p_proxy_store` WRITE;
/*!40000 ALTER TABLE `p_proxy_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_proxy_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `p_transport_category`
--

DROP TABLE IF EXISTS `p_transport_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p_transport_category` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `category_code` varchar(255) DEFAULT NULL,
  `category_name` varchar(255) DEFAULT NULL,
  `is_deleted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `p_transport_category`
--

LOCK TABLES `p_transport_category` WRITE;
/*!40000 ALTER TABLE `p_transport_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `p_transport_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user`
--

DROP TABLE IF EXISTS `t_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user`
--

LOCK TABLES `t_user` WRITE;
/*!40000 ALTER TABLE `t_user` DISABLE KEYS */;
INSERT INTO `t_user` VALUES (1,'zhaozheyun','123456'),(2,'zhaozheyun','123456'),(3,'zhaozheyun','123456'),(4,'zhaozheyun','123456');
/*!40000 ALTER TABLE `t_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `z_file`
--

DROP TABLE IF EXISTS `z_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `z_file` (
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `file_id` varchar(255) DEFAULT '',
  `file_name` varchar(255) DEFAULT '',
  `version` varchar(100) DEFAULT '1',
  `file_size` int(11) DEFAULT '0',
  `create_id` varchar(255) DEFAULT '',
  `create_time` varchar(255) DEFAULT '',
  `maintainer_id` varchar(255) DEFAULT '',
  `maintainer_time` varchar(255) DEFAULT '',
  `download_url` varchar(10000) DEFAULT '',
  `delete` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `z_file`
--

LOCK TABLES `z_file` WRITE;
/*!40000 ALTER TABLE `z_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `z_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `z_file_acl`
--

DROP TABLE IF EXISTS `z_file_acl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `z_file_acl` (
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `user_id` varchar(255) DEFAULT '',
  `file_id` varchar(255) DEFAULT '',
  `permission` varchar(255) DEFAULT 'read',
  `rename` varchar(100) DEFAULT '0',
  `history` varchar(100) DEFAULT '0',
  `copy` varchar(100) DEFAULT '0',
  `export` varchar(100) DEFAULT '0',
  `print` varchar(100) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `z_file_acl`
--

LOCK TABLES `z_file_acl` WRITE;
/*!40000 ALTER TABLE `z_file_acl` DISABLE KEYS */;
/*!40000 ALTER TABLE `z_file_acl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `z_file_version`
--

DROP TABLE IF EXISTS `z_file_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `z_file_version` (
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `file_id` varchar(255) DEFAULT '',
  `file_version_id` varchar(255) DEFAULT '',
  `file_name` varchar(255) DEFAULT '',
  `version` varchar(100) DEFAULT '1',
  `download_url` varchar(10000) DEFAULT '',
  `file_size` int(11) DEFAULT '0',
  `create_id` varchar(255) DEFAULT '',
  `create_time` varchar(255) DEFAULT '',
  `maintainer_id` varchar(255) DEFAULT '',
  `maintainer_time` varchar(255) DEFAULT '',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `z_file_version`
--

LOCK TABLES `z_file_version` WRITE;
/*!40000 ALTER TABLE `z_file_version` DISABLE KEYS */;
/*!40000 ALTER TABLE `z_file_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `z_file_watermark`
--

DROP TABLE IF EXISTS `z_file_watermark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `z_file_watermark` (
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `file_id` varchar(255) DEFAULT '',
  `type_name` int(11) DEFAULT '0',
  `mark_value` varchar(255) DEFAULT '',
  `fillstyle` varchar(255) DEFAULT '',
  `font` varchar(255) DEFAULT '',
  `rotate` double(10,2) DEFAULT '0.00',
  `horizontal` double(10,2) DEFAULT '0.00',
  `vertical` double(10,2) DEFAULT '0.00',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `z_file_watermark`
--

LOCK TABLES `z_file_watermark` WRITE;
/*!40000 ALTER TABLE `z_file_watermark` DISABLE KEYS */;
/*!40000 ALTER TABLE `z_file_watermark` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `z_user`
--

DROP TABLE IF EXISTS `z_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `z_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `avatar_url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `z_user`
--

LOCK TABLES `z_user` WRITE;
/*!40000 ALTER TABLE `z_user` DISABLE KEYS */;
INSERT INTO `z_user` VALUES (1,'用户1',''),(2,'用户2','');
/*!40000 ALTER TABLE `z_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'java-study1'
--

--
-- Dumping routines for database 'java-study1'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-30  3:42:25
