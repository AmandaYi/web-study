// 引入css文件
import "./css/index.css"
// 引入SASS文件
import "./scss/index.scss"
// 引入LESS文件
import "./less/index.less"
let title = document.getElementById("title")
title.innerHTML = "Hello webpack4!"

