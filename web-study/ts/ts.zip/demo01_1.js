"use strict";
var age = 18;
var stature = 184;
console.log(age);
console.log(stature);
