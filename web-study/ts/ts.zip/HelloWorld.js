"use strict";
var str = "Hello World";
console.log(str);
