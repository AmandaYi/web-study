"use strict";
// 枚举
var REN;
(function (REN) {
    REN["nan"] = "\u7537";
    REN["nv"] = "\u5973";
    REN["yao"] = "\u5996";
})(REN || (REN = {}));
console.log(REN.yao);
var world;
world = "世界";
world = true;
world = 0;
console.log(world);
