var age :number =18 
var stature :number= 184
console.log(age)
console.log(stature)