// 枚举
enum REN { nan = "男", nv = "女", yao = "妖" }
console.log(REN.yao)






var world: any
world = "世界"
world = true
world = 0
console.log(world)


